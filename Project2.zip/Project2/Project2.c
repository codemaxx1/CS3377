//Project 2
//Should be called mysh.c
/*



*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

//initialize
int chdir(const char *path);
char *getcwd(char *buf, int size);

//get and run the command from the input string
int getCommand(char* string, char** terms, char *HOME)
{
        //variable definitions
        //printf("CHECKING STATUS GETCOMMAND: home:%s\n", HOME);
        int i, termsNumber, commandOptionsLength, r;
        char buf[256];
        char *s;
        char* command[] = {"ls","mkdir", "rmdir", "cd", "pwd", "creat", "rm", "reload", "save", "menu", "quit", "exit", NULL};

        //printf("CHECKING STATUS GETCOMMAND: command string: %s\n", string);


        //run the command
        for(i = 1; command[i] != NULL; i++);
        commandOptionsLength = i;
        for(i = 1; i < commandOptionsLength; i++)
        {
	        if(!strcmp(string, command[i]))
	        {
		        //char *cmd[] = {"ls","mkdir", "rmdir", "cd", "pwd", "creat", "rm", "reload", "save", "menu", "quit", "exit" NULL};
		        //printf("CHECKING STATUS GETCOMMAND: strings are equal: %s, %s\n", string, command[i]);
		        switch(i)
		        {
		                //cd
			        case 3:
				        //printf("CHECKING STATUS GETCOMMAND: cd was entered; changing directory logic... \n");
			                //if the user typed in a path
			                if(terms[1]!=NULL && strcmp(terms[1],"") && strstr(terms[1], "/") != NULL)
			                {
		                                //printf("CHECKING STATUS GETCOMMAND: changing directory to \"%s\"\n",terms[1]);
			                        r = chdir(terms[1]);
			                        s = getcwd(buf, 256);
		                                //printf("CHECKING STATUS GETCOMMAND: new directory is: %s\n", s);
		                        }
		                        //if the user didn't type in a path
		                        else 
		                        {   
	                                        //printf("CHECKING STATUS GETCOMMAND: going to the home directory: %s\n", HOME); 
	                                        r = chdir(HOME);
		                                s = getcwd(buf, 256);
		                                //printf("CHECKING STATUS GETCOMMAND: new directory is: %s\n", s);
		                        }
				        break;
			        
			        //exit
			        case 11:
				        //printf("CHECKING STATUS GETCOMMAND: command exit will run in 3... 2... 1...\n");
				        exit(1);
				        //printf("CHECKING STATUS GETCOMMAND: the system should have exited by now\n");
				        break;
			        default:
				        printf("CHECKING STATUS GETCOMMAND: the string entered isn't found the the cases\n");
				        
		        }
	        }
	        //printf("CHECKING STATUS GETCOMMAND: command: %d : %s\n",i, command[i]);
        }

        return -1;      
}





int main(int argc, char *argv[], char *env[ ])
{

        //start while infinite loop
        while(1){
                char* HOME;
                char* tokString;
                char* cmd;
                char* terms = NULL;
                char sum[64];
                int iteration, i;
                printf("user:~$ ");

                char command[64];
                fgets(command,64,stdin);
                command[strlen(command) -1] = 0;
                //printf("CHECKING STATUS MAIN: command =  %s, len(command) = %d.\n",command, (int) strlen(command)); 

                //tokenize the inputted command string
                iteration = 0;
                tokString = strtok (command," ");
                char* tokenizedStringArray[64];
                while (tokString != NULL)
                {
	                if(iteration == 0)
	                {
		                cmd = tokString;
	                }
	               
	                //printf ("CHECKING STATUS MAIN: tokenized Word %d: %s, length(word): %d\n",iteration, tokString, (int) strlen(tokString));
	                tokenizedStringArray[iteration] = tokString;
	                tokString = strtok (NULL, " ");
	                iteration++;
                }


                if(tokenizedStringArray[0] == NULL || !strcmp(tokenizedStringArray[0]," "))
                {
                        printf("CHECKING STATUS MAIN: the terms in thew string is null... pardon my grammar\n");
                        for(i = 0; tokenizedStringArray[i] != NULL; i++)
                        {
                                tokenizedStringArray[i] = NULL;
                        }
                }
                /*
                for(i = 0; i < iteration; i++)
                {
	                printf("CHECKING STATUS MAIN: term in the sting: %d \twhich is:%s\n",i, tokenizedStringArray[i]);
                }
                */
                

                //call command from term 1; enter the rest of the terms.
                //printf("CHECKING STATUS MAIN: length of cmd: %ld, cmd:%s\n", strlen(cmd), cmd);
                
                
                for(i = 0; env[i] != NULL; i++)
                {
                        //printf("CHECKING STATUS MAIN: %s\n", env[i]);
                        if(strstr(env[i], "HOME=") != NULL && !strstr(env[i],"GRADLE_HOME="))
                        {
                                HOME = env[i];
                                printf("CHECKING STATUS MAIN: \"Home\" is %s\n", HOME);
                                //tokenize the inputted command string
                                iteration = 0;
                                char* tokHOME = strtok(HOME,"HOME=");
                                //tokHOME = strtok(tokHOME,"=");
                                HOME = tokHOME;
                                printf("CHECKING STATUS MAIN: new \"Home\" is %s\n", HOME);
                        }
                }
                printf("CHECKING STATUS MAIN: home=%s\n", HOME);
                
                printf("CHECKING STATUS MAIN: cmd=%s\n",cmd);
                for(i = 0; tokenizedStringArray[i]!=NULL;i++)
                {
                printf("CHECKING STATUS MAIN: tokenized string array:%s\n",tokenizedStringArray[i]);
                }
                getCommand(cmd, tokenizedStringArray, HOME);


                
                //end while infinite loop
        }

        return -1;
}
