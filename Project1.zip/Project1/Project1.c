//CS 3377 project 1
//Nick Garrett


# include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define LEN 64

int i;
char input[LEN];
struct node {
   int data; 
	
   struct node *leftChild;
   struct node *rightChild;
};

//node *root, *cwd;               //root and cwd pointers

char line[128];                 //user inputStruct
char command[16];               //command and pathname strings
char dname[64], bname[64];      //dirname  and basename string holders
char pathname[64];



//innit
int initialize()
{
        return -1;
}





//mkdir
int mkdir(char pathname[])
{
        printf("mkdir");
        return -1;
} 

//rmdir
int rmdir(char pathname[])
{
        printf("rmdir");
        return -1;
} 

//cd
int cd(char pathname[])
{
        printf("cd");
        return -1;
} 

//ls
int ls(char pathname[])
{
        printf("ls");
        return -1;
} 

//pwd
int pwd(char pathname[])
{
        printf("pwd");
        return -1;
} 

//creat
int creat(char pathname[])
{
        printf("creat");
        return -1;
} 

//rm
int rm(char pathname[])
{
        printf("rm");
        return -1;
} 

//save
int save(char pathname[])
{
        printf("save");
        return -1;
} 

//reload
int reload(char pathname[])
{
        printf("reload");
        return -1;
} 

//menu
int menu(char pathname[])
{
        printf("menu");
        return -1;
} 

//quit
int quit()
{
        
        return -1;
}




char *cmd[] = {"mkdir", "rmdir", "ls", "cd", "pwd", "creat", "rm", "reload", "save", "menu", "quit", NULL};
int findCmd(char *command)
{
printf("findCMD");
        int i = 0;
        while(cmd[i]){
                if(!strcmp(command, cmd[i])){
                        //printf("term: \"%d\" at point: %d \n",command[i], i);
                        return i;       //found command: return index i
                        //i = 0;
                }
                
                i++;
                //printf("new term: \"%d\" at point: %d \n",command[i], i);
        }        
        return -1;                      //command not found: return -1
}

     
        
//tokenize
struct tokenizedStringStruct
{
char **tokenizedStringArray;
int numberOfWords;
};

struct tokenizedStringStruct inputStruct; //declare inputStruct as 
void tokenize (char *input)
{
         
        char *tokenizedString;
        
        i = 0;
        inputStruct.numberOfWords = 0;

        tokenizedString = strtok(input, " ");
           

        while( tokenizedString != NULL ) 
        {
                inputStruct.numberOfWords++;
                printf("\033[95mCHECK AT *TOKENIZE: token %ld: %s\033[0m\n",strlen(tokenizedString),tokenizedString);
                printf( " %s\n", tokenizedString);
                inputStruct.tokenizedStringArray[i++] = tokenizedString;
                
                tokenizedString = strtok(NULL, " ");
        }
        
        //return tokenizedStringArray,numberOfWords;
}

int main()
{
        initialize();           //initialize root node of the file system tree
        
        while(1){
        //get user input
        printf("user:~$ ");
        fgets(input, LEN, stdin);
        line[strlen(input) -1] = 0;  //kill "\n" at the end of the stirng
        
        //tokenize the input string
        tokenize(input);
        for(i = 0; i < inputStruct.numberOfWords; i++)
        {
                printf("\033[94mCHECK AT MAIN%s \033[0m\n",inputStruct.tokenizedStringArray[i]);
        }
        
        /*
        switch( index)
        {
                case 0:
                        mkdir(pathname);        
                        break;
                        
                case 1:
                        rmdir(pathname);        
                        break;
                
                case 2:
                        ls( pathname);           
                        break;
                        
                default:
                        printf("%s: command not found", command);
        }
        
        */
        

                //get user inputStruct line = [command pathname] ;
                //identify the command;
                //execute the command;
                //break if command = "quit";
        }
        
        
}
